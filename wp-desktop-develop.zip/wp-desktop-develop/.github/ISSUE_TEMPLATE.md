<!-- Thanks for contributing to Wordpress.com for Desktop! Pick a clear title ("Editor: add spell check") and proceed. -->

#### Steps to reproduce
1.
2.
3.
4.

#### What I expected


#### What happened instead


#### App Version / OS version


#### Screenshot / Video


#### Context / Source
<!-- Optional: share your unique context to help us understand your perspective. You can add context tags such as: #journey #anecdote #narrative #context #empathy #perspective #reallife #dogfooding #livesharing #flowsharing #anxiety #anxiety-flow #stresscase #painpoint.

We'd also love to know how you found the bug: #dogfooding, #manual-testing, #automated-testing, or #user-report if applicable.

If requesting a new feature, explain why you'd like to see it added.
-->



<!--
PLEASE NOTE
- These comments won't show up when you submit the issue.
- Everything is optional, but try to add as many details as possible.

Docs & troubleshooting:
https://github.com/Automattic/wp-calypso/blob/master/CONTRIBUTING.md
https://github.com/Automattic/wp-desktop/blob/master/docs/troubleshooting.md

Helpful tips for screenshots:
https://en.support.wordpress.com/make-a-screenshot/
-->