Preferences
=========

Monitors for preference IPC messages and updates the settings file.

## IPC messages

Listens for the following:

- `preferences-changed-proxy-type` - proxy changed, tell user to restart the app
- `preferences-changed` - a preference setting has changed
