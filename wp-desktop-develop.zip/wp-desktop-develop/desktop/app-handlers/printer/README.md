Printer
=========

Provides a way for Calypso to print. This is used for printing backup codes.

## IPC messages

Listens for the following:

- `print` - print a given bit of HTML
