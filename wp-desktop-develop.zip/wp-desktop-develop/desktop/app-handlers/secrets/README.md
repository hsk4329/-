Secrets
=========

Show a secret screen. Shhh.

## IPC messages

Listens for the following:

- `secrets` - which secret to show
