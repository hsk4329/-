Updater
=========

Uses either the manual or auto updater to check for updates.

The config `updater.url` is used as the base URL and has the platform, version, and beta setting appended.

The updater uses:

- [Auto Updater](auto-updater/README.md)
- [Manual Updater](manual-updater/README.md)
