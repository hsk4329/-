Manual Updater
=========

Provides a manual updater on platforms where the auto updater does not work.

If an update is detected then a dialog is shown with a link to the update for download.

The update is shown once until the app is restarted.

## Functions

`ping()` - checks for an update
