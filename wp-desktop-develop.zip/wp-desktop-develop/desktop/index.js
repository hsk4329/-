/**
 * Internal dependencies
 */
require( './app' )();
