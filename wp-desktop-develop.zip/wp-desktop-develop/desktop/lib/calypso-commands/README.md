Calypso Commands
=========

Sends commands via IPC to Calypso.

The following commands are available:

- `showMySites`
- `showReader`
- `showProfile`
- `newPost`
- `toggleNotifications`
- `signOut`
