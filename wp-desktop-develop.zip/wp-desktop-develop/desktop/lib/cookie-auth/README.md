Cookie Auth
=========

Sets a WordPress.com login cookie using the OAuth token. This is required for the notifications client and post previews to work.
