Debug Tools
=========

Provides a few tools to debug the app.

## Functions

`debug.dialog( message )` - display a dialog with a message

Where:

- `message` - a message to display in a dialog

`debug.log( values )` - log anything to a temporary file
