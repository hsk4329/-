Mac Platform
==========

Provides Mac specific platform features.

## Notification Badge

Uses the dock and has a bounce ability.

## Dock Menu

Standard dock right-click menu.

## Closing & Quitting

The app will close to the dock.

To quit the app, right-click on the dock and pick close.
