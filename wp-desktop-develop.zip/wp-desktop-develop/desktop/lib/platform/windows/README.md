Windows Platform
==========

Provides Windows specific platform features.

## Notification Badge

Sets an icon in the system tray. No bounce

## Dock Menu

Sets a context menu in the system tray.

## Closing & Quitting

When closed the app will be removed from the taskbar.

When first closed a notification balloon will indicate how to re-open the app.

To re-open the app click in the system tray.

To quit the app, right-click in the system tray and pick quit.
