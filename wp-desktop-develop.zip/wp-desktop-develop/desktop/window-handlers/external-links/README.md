External Links
=========

Hooks into the `will-navigate` and `new-window` events to override Calypso behavior.

The following rules are applied:
- All external links (with a few exceptions) are opened in a browser
- Excepted external links are allowed to open a new Electron window
