Window Saver
=========

Saves the window position and size when changed.
